package M1D_training_Fees_4athletes;

import java.util.Scanner;

public abstract class Athletes {
    private String  name;
    private String trainingPlan;
    private double weight;
    private String weightCategory;
    private int noOfCompetition;
    private int noOfHour;

    //encapsulation
    public String getName() {
        return name;
    }

    public String getTrainingPlan() {
        return trainingPlan;
    }

    public double getCurrentWeight() {
        return weight;
    }

    public String getWeightCategory() {
        return weightCategory;
    }

    public int getNumberOfCompetitions() {
        return noOfCompetition;
    }

    public int getHourOfPrivateCoaching() {
        return noOfHour;
    }

    public abstract double calculateTrainingFee();

    public abstract double compareWeight();


    public Athletes(String name, String trainingPlan, double weight, String weightCategory,
                   int noOfCompetition, int noOfHour) {
        this.name = name;
        this.trainingPlan = trainingPlan;
        this.weight = weight;
        this.weightCategory = weightCategory;
        this.noOfCompetition = noOfCompetition;
        this.noOfHour =  noOfHour;
    }

    public void setAthleteInformation() {
        Scanner sc = new Scanner(System.in);
        athleteName(sc);
        trainingPlan(sc);
        currentWeight(sc);
        weightCategory(sc);
        numberOfCompetitions(sc);
        hourOfPrivateCoaching(sc);
    }

    //Req name
    private void athleteName(Scanner sc) {
    String name = "";
        while (name.isEmpty() || !name.matches("([A-Z][a-z]+)(\\s[A-Z][a-z]+)*")) {
        System.out.print("Please enter Athlete name: ");
        name = sc.nextLine().trim();

        if (name.isEmpty()) {
            System.out.println("Name can't be empty!!! Please enter your name.");
        } else if (!name.matches("([A-Z][a-z]+)(\\s[A-Z][a-z]+)*")) {
            System.out.println("Invalid format!!! Please write the first name  in capital letters.");
        }
    }
        this.name = name;
}

    //Req current weight
    private void currentWeight(Scanner sc) {
        boolean validInput = false;
        while (!validInput) {
            System.out.println("Enter your current Weight(in kg)");

            if (sc.hasNextDouble()) {
                double weight = sc.nextDouble();
                sc.nextLine();

                if (weight < 0 || weight >= 66) {
                    this.weight = weight;
                    validInput = true;
                } else {
                    System.out.println("Invalid weight!!! Please enter again.");
                }
            } else {
                System.out.println("Invalid weight!!! Please enter again.");
                sc.nextLine();
            }
        }
    }

    //Req weight category
    private void weightCategory(Scanner sc) {
        boolean validWeight= false;
        while (!validWeight) {
            System.out.print("Enter your weight category: ");
            System.out.println("1.Heavyweight(over 100kg)");
            System.out.println("2.light-Heavyweight(100kg)");
            System.out.println("3.Middleweight(90kg)");
            System.out.println("4.Light-Middleweight(81kg)");
            System.out.println("5.Lightweight(73kg)");
            System.out.println("6.Flyweight(66kg)");

            String input = sc.nextLine();
            switch (input) {
                case "1":
                    this.weightCategory = "Heavyweight";
                    validWeight = true;
                    break;
                case "2":
                    this.weightCategory = "Light-Heavyweight";
                    validWeight = true;
                    break;
                case "3":
                    this.weightCategory = "Middleweight";
                    validWeight = true;
                    break;
                case "4":
                    this.weightCategory = "Light-Middleweight";
                    validWeight = true;
                    break;
                case "5":
                    this.weightCategory = "Lightweight";
                    validWeight = true;
                    break;
                case "6":
                    this.weightCategory = "Flyweight";
                    validWeight = true;
                    break;
                default:
                    System.out.println("Invalid weight category!!! Please enter again.");
                    break;
            }
        }
    }

    //Req training plan
    private void trainingPlan(Scanner sc) {
        boolean validOption = false;
        while (!validOption) {
            System.out.println("This is weekly fee for the training plan");
            System.out.println("1.Beginner(2 sessions per week) weekly fee: 23.00$");
            System.out.println("2.Intermediate(3 sessions per week) weekly fee: 30.00$");
            System.out.println("3.Elite(5 sessions per week) weekly fee: 35.00$");


            //Req training plan
            System.out.print("Choose your training plan:");
            String input = sc.nextLine();
            if (input.equalsIgnoreCase("1")) {
                this.trainingPlan = "Beginner";
                validOption = true;
            } else if (input.equalsIgnoreCase("2")) {
                this.trainingPlan = "Intermediate";
                validOption = true;
            } else if (input.equalsIgnoreCase("3")) {
                this.trainingPlan = "Elite";
                validOption = true;
            } else {
                System.out.println("Invalid training plan!!! Please according to the list.");
            }
        }
    }

    //Req number of completion
    private void numberOfCompetitions(Scanner sc) {
        if (this.trainingPlan.equalsIgnoreCase("Beginner")) {
        } else if (this.trainingPlan.equalsIgnoreCase("Intermediate") || this.trainingPlan.equalsIgnoreCase("Elite")) {
            boolean validNumberOfCompetitions = false;
            while (!validNumberOfCompetitions) {
                System.out.print("Enter the number of competitions you have participated");

                if (sc.hasNextInt()) {
                    int competitions = sc.nextInt();
                    sc.nextLine();

                    if (competitions >= 0 && competitions <= 2) {
                        this.noOfCompetition = competitions;
                        validNumberOfCompetitions = true;
                    } else {
                        System.out.println("Invalid number!!! Please enter again.\n");
                    }
                } else {
                    System.out.println("Please enter a number");
                    sc.nextLine();
                }
            }
        }
    }

    //Req hour of private coaching
    private void hourOfPrivateCoaching(Scanner sc) {
        boolean validHourOfPrivateCoaching = false;
        while (!validHourOfPrivateCoaching) {

            System.out.println("Athlete can receive a maximum of five hours’ private coaching a week");
            System.out.println("Enter the number of hours for private coaching you want to train");

            if (sc.hasNextInt()) {
                int hours = sc.nextInt();
                sc.nextLine();

                if (hours >= 0 && hours <= 20) {
                    this.noOfHour = hours;
                    validHourOfPrivateCoaching = true;
                } else {
                    System.out.println("The coaching hour can't be more than 20 hours for a month!!! Please enter again");
                }
            } else {
                System.out.println("Please enter a valid number.");
                sc.nextLine();
            }
        }
    }
}
