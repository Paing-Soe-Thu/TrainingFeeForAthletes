package M1D_training_Fees_4athletes;

public class MonthlyFeeCalculate extends Athletes {

    public MonthlyFeeCalculate(String name, String trainingPlan, double weight, String weightCategory, int noOfCompetition, int noOfHour) {
        super(name, trainingPlan, weight, weightCategory, noOfCompetition, noOfHour);
    }

    @Override
    public double calculateTrainingFee() {
        double weeklyFee;
        switch (getTrainingPlan()) {
            case "Beginner":
                weeklyFee = 25.0;
                break;
            case "Intermediate":
                weeklyFee = 30.0;
                break;
            case "Elite":
                weeklyFee = 35.0;
                break;
            default:
                weeklyFee = 0.0;
                break;
        }

        double competitionFee = 22 * getNumberOfCompetitions();
        double coachingExpense = getHourOfPrivateCoaching() * 9;
        double feePerWeek = weeklyFee + coachingExpense;
        double feePerMonth = feePerWeek * 4 * competitionFee;
        return feePerMonth;
    }

    @Override
    public double compareWeight() {
        double weightC = 0.0;
        switch (getWeightCategory()) {
            case "Heavyweight":
                weightC = 101;
                break;
            case "Light-Heavyweight":
                weightC = 100;
                break;
            case "Middleweight":
                weightC = 90;
                break;
            case "Light-Middleweight":
                weightC = 81;
                break;
            case "Lightweight":
                weightC = 73;
                break;
            case "Flyweight":
                weightC = 66;
                break;
            default:
                weightC = 0;
                break;
        }

        double currentW = getCurrentWeight();
        return weightC - currentW;
    }
}