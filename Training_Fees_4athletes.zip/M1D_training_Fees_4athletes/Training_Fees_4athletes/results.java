package M1D_training_Fees_4athletes;

import java.util.InputMismatchException;
import java.util.Scanner;

public class results {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Welcome To North Sussex Judo Training Center");

        //Req num of Athletes
        while (true) {
            int noOfAthlete = 0;
        do {
            System.out.println("Please enter the number of athletes: ");
            try {
                noOfAthlete = input.nextInt();
                if (noOfAthlete < 1) {
                    System.out.println("Minimum 1 athlete is required. Please try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter number of Athlete(s).");
                input.next();
            }
        } while (noOfAthlete < 1);

        //Output
        for (int a = 1; a <= noOfAthlete; a++) {
            System.out.printf("Enter details of Athlete %d\n", a);
            MonthlyFeeCalculate userInput = new MonthlyFeeCalculate("", "", 0, "", 0, 0);
            userInput.setAthleteInformation();
            double trainingFee = userInput.calculateTrainingFee();
            double weightDifference = userInput.compareWeight();
            System.out.println("**********Athlete " + a + " Information**********");
            System.out.println("Athlete Name: " + userInput.getName());
            System.out.println("Training Plan: " + userInput.getTrainingPlan());
            System.out.println("Current Weight: " + userInput.getCurrentWeight() + " kg");
            System.out.println("Weight Category: " + userInput.getWeightCategory());
            System.out.println("Number of Competitions: " + userInput.getNumberOfCompetitions());
            System.out.println("Hours of Private Coaching: " + userInput.getHourOfPrivateCoaching());
            System.out.println("Total Fees: " + String.format("%.2f", trainingFee) + "$");
            System.out.println("Weight Difference: " + weightDifference + " kg");
            System.out.println("---------------------------------------------------------------------------------------------------------");
            System.out.println("Thank you " + userInput.getName() + "You successfully registered to the North Sussex Judo Training Center");
            System.out.println("****************************** Welcome " +  userInput.getName() + "**************************************");
            System.out.println("---------------------------------------------------------------------------------------------------------");
        }
        //result program
            System.out.println("Do you want to restart (y/n)?");
            String restartInput = input.next();
            if (!restartInput.equalsIgnoreCase("y")) {
            }
        }
    }
}
